# this file will contain global functions
# these functions will be used throughout all files
# whats the point writing the same code more than once

import os


def clearScreen():
    '''
        This function clears the screen

        This function does not require any parameters
        This function does not return anything
    '''

    os.system("cls")
